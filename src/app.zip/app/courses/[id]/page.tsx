'use client';

import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Course, Lesson } from '@/types';
// Removed RequireAuth import - course details should be viewable without login
import SecurePlayer from '@/components/course/SecurePlayer';
import LessonsList from '@/components/course/LessonsList';
import CourseHeader from '@/components/course/CourseHeader';
import SkeletonLoader from '@/components/ui/SkeletonLoader';
// import { checkEnrollmentStatus } from '@/lib/checkout'; // Temporarily disabled to prevent Stripe API errors
// import PayPalButton from '@/components/payment/PayPalButton'; // Temporarily disabled to prevent payment errors
import { ChevronLeftIcon, ChevronRightIcon, CheckIcon } from '@heroicons/react/24/outline';

interface CourseProgress {
  completedLessons: string[];
  currentLesson: string;
  progressPercentage: number;
}

export default function CoursePage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  // Removed useCourses hook - now fetching directly from API
  
  const courseId = params.id as string;
  const [course, setCourse] = useState<Course | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentLessonId, setCurrentLessonId] = useState<string>('');
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [progress, setProgress] = useState<CourseProgress>({
    completedLessons: [],
    currentLesson: '',
    progressPercentage: 0
  });
  const [sidebarOpen, setSidebarOpen] = useState(false);
  // Removed purchase loading state - handled by PayPal component

  // Load course data from API
  useEffect(() => {
    const loadCourse = async () => {
      if (!courseId) {
        setError('معرف الدورة غير صحيح');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);
        
        console.log(`🔍 Fetching course data for ID: ${courseId}`);
        
        const response = await fetch(`/api/courses/${courseId}`);
        
        if (!response.ok) {
          if (response.status === 404) {
            setError('الدورة غير موجودة');
            return;
          }
          
          const errorData = await response.json().catch(() => ({}));
          setError(errorData.error || 'حدث خطأ أثناء تحميل الدورة');
          return;
        }
        
        const courseData: Course = await response.json();
        console.log(`✅ Successfully loaded course: ${courseData.title}`);
        
        setCourse(courseData);
        
        // Set first lesson as current if none selected
        if (courseData.lessons && courseData.lessons.length > 0) {
          setCurrentLessonId(courseData.lessons[0].id);
        }
        
        // Check user enrollment after course is loaded
        checkUserEnrollment(courseId);
        
      } catch (error) {
        console.error('❌ Error loading course:', error);
        setError('حدث خطأ أثناء الاتصال بالخادم');
      } finally {
        setLoading(false);
      }
    };

    loadCourse();
  }, [courseId]);

  // Load progress from localStorage
  const loadProgress = () => {
    const savedProgress = localStorage.getItem(`course_progress_${courseId}`);
    if (savedProgress) {
      const progressData = JSON.parse(savedProgress);
      setProgress(progressData);
      if (progressData.currentLesson) {
        setCurrentLessonId(progressData.currentLesson);
      }
    }
  };

  // Save progress to localStorage
  const saveProgress = (newProgress: CourseProgress) => {
    localStorage.setItem(`course_progress_${courseId}`, JSON.stringify(newProgress));
    setProgress(newProgress);
  };

  // Check enrollment status
  useEffect(() => {
    if (course) {
      if (user) {
        // In a real app, this would check against user's purchased courses
        // For now, we'll simulate enrollment for demo purposes
        const enrolled = Math.random() > 0.5; // 50% chance of being enrolled
        setIsEnrolled(enrolled);
        
        if (enrolled) {
          loadProgress();
        }
      } else {
        // User not logged in - not enrolled
        setIsEnrolled(false);
      }
    }
  }, [user, course]);

  // Check enrollment status - temporarily mocked to prevent Stripe API errors
  const checkUserEnrollment = async (courseId: string) => {
    if (user) {
      try {
        // Mock enrollment check - always returns false for demo
        // TODO: Replace with actual enrollment check when payment system is configured
        const enrolled = false;
        setIsEnrolled(enrolled);
      } catch (error) {
        console.error('Error checking enrollment:', error);
        setIsEnrolled(false);
      }
    } else {
      setIsEnrolled(false);
    }
  };

  // PayPal handlers temporarily disabled
  // const handlePayPalSuccess = (details: any) => {
  //   console.log('PayPal payment successful:', details);
  //   // Refresh enrollment status
  //   checkUserEnrollment(courseId);
  //   // Show success message
  //   alert('تم الشراء بنجاح! يمكنك الآن الوصول إلى جميع دروس الكورس.');
  // };

  // const handlePayPalError = (error: any) => {
  //   console.error('PayPal payment error:', error);
  //   alert('حدث خطأ أثناء عملية الدفع. يرجى المحاولة مرة أخرى.');
  // };

  // const handlePayPalCancel = () => {
  //   console.log('PayPal payment cancelled');
  //   // Optionally show a message or redirect
  // };

  // Mark lesson as complete
  const markLessonComplete = (lessonId: string) => {
    if (!isEnrolled) return;
    
    const newCompletedLessons = [...progress.completedLessons];
    if (!newCompletedLessons.includes(lessonId)) {
      newCompletedLessons.push(lessonId);
    }
    
    const totalLessons = course?.lessons?.length || 0;
    const progressPercentage = Math.round((newCompletedLessons.length / totalLessons) * 100);
    
    const newProgress = {
      ...progress,
      completedLessons: newCompletedLessons,
      currentLesson: currentLessonId,
      progressPercentage
    };
    
    saveProgress(newProgress);
  };

  // Navigate to next/previous lesson
  const navigateLesson = (direction: 'next' | 'prev') => {
    if (!course?.lessons) return;
    
    const currentIndex = course.lessons.findIndex(lesson => lesson.id === currentLessonId);
    let newIndex;
    
    if (direction === 'next') {
      newIndex = currentIndex + 1;
    } else {
      newIndex = currentIndex - 1;
    }
    
    if (newIndex >= 0 && newIndex < course.lessons.length) {
      setCurrentLessonId(course.lessons[newIndex].id);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <SkeletonLoader type="course" />
      </div>
    );
  }

  if (error || !course) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            {error || 'الكورس غير موجود'}
          </h1>
          <p className="text-gray-600 mb-6">
            {error === 'الدورة غير موجودة' 
              ? 'عذراً، لم نتمكن من العثور على الكورس المطلوب' 
              : error === 'معرف الدورة غير صحيح'
              ? 'معرف الدورة المطلوب غير صحيح'
              : 'حدث خطأ أثناء تحميل الدورة. يرجى المحاولة مرة أخرى'
            }
          </p>
          <div className="space-y-3">
            <button 
              onClick={() => window.location.reload()}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 w-full"
            >
              إعادة المحاولة
            </button>
            <button 
              onClick={() => router.push('/courses')}
              className="bg-gray-200 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-300 w-full"
            >
              العودة إلى الكورسات
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentLesson = course.lessons?.find(lesson => lesson.id === currentLessonId);
  const currentLessonIndex = course.lessons?.findIndex(lesson => lesson.id === currentLessonId) || 0;
  const isLessonCompleted = progress.completedLessons.includes(currentLessonId);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Course Header */}
      <CourseHeader 
        course={course}
        isEnrolled={isEnrolled}
        progress={progress.progressPercentage}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content - Video Player */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              {isEnrolled ? (
                <div>
                  {/* Video Player */}
                  <div className="relative">
                    {currentLesson ? (
                      <SecurePlayer
                        videoUrl={currentLesson.videoUrl}
                        title={currentLesson.title}
                        onProgress={() => {}}
                      />
                    ) : (
                      <div className="aspect-video bg-gray-200 flex items-center justify-center">
                        <p className="text-gray-500">لا يوجد درس محدد</p>
                      </div>
                    )}
                  </div>

                  {/* Lesson Info and Controls */}
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h2 className="text-xl font-bold text-gray-900 mb-2">
                          {currentLesson?.title}
                        </h2>
                        <p className="text-sm text-gray-600">
                          الدرس {currentLessonIndex + 1} من {course.lessons?.length}
                        </p>
                      </div>
                      
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <button
                          onClick={() => navigateLesson('prev')}
                          disabled={currentLessonIndex === 0}
                          className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <ChevronRightIcon className="w-5 h-5" />
                        </button>
                        
                        <button
                          onClick={() => navigateLesson('next')}
                          disabled={currentLessonIndex === (course.lessons?.length || 0) - 1}
                          className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <ChevronLeftIcon className="w-5 h-5" />
                        </button>
                      </div>

                      <button
                        onClick={() => markLessonComplete(currentLessonId)}
                        disabled={isLessonCompleted}
                        className={`px-6 py-2 rounded-lg font-medium ${
                          isLessonCompleted
                            ? 'bg-green-100 text-green-700 cursor-not-allowed'
                            : 'bg-blue-600 text-white hover:bg-blue-700'
                        }`}
                      >
                        {isLessonCompleted ? 'مكتمل' : 'تم الانتهاء'}
                      </button>
                    </div>

                    {/* Lesson Description */}
                    {currentLesson?.description && (
                      <div className="mt-6">
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">وصف الدرس</h3>
                        <p className="text-gray-700 leading-relaxed">
                          {currentLesson.description}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                // Locked State - Not Enrolled or Not Logged In
                <div className="bg-white rounded-lg shadow-lg p-8 text-center">
                  <div className="mb-6">
                    <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">محتوى مقفل</h3>
                    {!user ? (
                      <>
                        <p className="text-gray-600 mb-6">
                          يجب تسجيل الدخول أولاً للوصول إلى محتوى الكورس
                        </p>
                        <div className="space-y-3">
                          <button 
                            onClick={() => router.push('/auth/login')}
                            className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 w-full"
                          >
                            تسجيل الدخول
                          </button>
                          <button 
                            onClick={() => router.push('/auth/register')}
                            className="bg-gray-200 text-gray-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-300 w-full"
                          >
                            إنشاء حساب جديد
                          </button>
                        </div>
                      </>
                    ) : (
                      <>
                        <p className="text-gray-600 mb-6">
                          يجب شراء الكورس للوصول إلى الدروس والمحتوى
                        </p>
                        <div className="space-y-4">
                          {/* PayPal button temporarily disabled */}
                          <div className="text-center">
                            <span className="text-3xl font-bold text-blue-600">${course.price}</span>
                            <span className="text-gray-500 text-sm block">دفعة واحدة - وصول مدى الحياة</span>
                          </div>
                          <button 
                            disabled
                            className="bg-gray-400 text-white px-8 py-3 rounded-lg font-semibold cursor-not-allowed w-full"
                          >
                            الدفع غير متاح حالياً
                          </button>
                          <p className="text-xs text-gray-500 text-center">
                            💳 سيتم تفعيل نظام الدفع قريباً
                          </p>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar - Lessons List */}
            <div className="lg:col-span-1">
              <LessonsList
                course={course}
                currentLessonId={currentLessonId}
                onLessonSelect={setCurrentLessonId}
                completedLessons={progress.completedLessons}
                isEnrolled={isEnrolled}
                isOpen={sidebarOpen}
                onClose={() => setSidebarOpen(false)}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}